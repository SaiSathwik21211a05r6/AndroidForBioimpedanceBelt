package com.example.eegreader.database

//Creating the repository for the grocery database
class StatusRepository(private val db:StatusDatabase) {

    //Function for adding new grocery
    suspend fun insertStatus(items: StatusList)=db.getStatusDao().insertstatus(items)

    //Function for deleting a grocery
    suspend fun deleteitem(items: StatusList)=db.getStatusDao().deletestatus(items)

    //Function to get the list of groceries
    fun getthelistofstatus()=db.getStatusDao().getthelistofstatus()
}