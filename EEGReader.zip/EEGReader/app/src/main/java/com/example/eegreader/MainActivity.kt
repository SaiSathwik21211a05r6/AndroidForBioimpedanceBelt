package com.example.eegreader

import android.Manifest
import android.app.ActionBar
import android.app.AlertDialog
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.util.Log
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.eegreader.BLEModule.*

import com.example.eegreader.BLEModule.OnDeviceScanListener
import com.example.eegreader.RecyclerView.PatientRecyclerAdaptor
import com.example.eegreader.database.PatientViewModal
import com.example.eegreader.database.Patientlist
import com.google.android.material.floatingactionbutton.FloatingActionButton



class MainActivity : AppCompatActivity(), OnDeviceScanListener {

    lateinit var itemsRV: RecyclerView
    lateinit var add: FloatingActionButton
    lateinit var list:List<Patientlist>
    lateinit var patientRecyclerAdaptor: PatientRecyclerAdaptor
    lateinit var patientViewModal: PatientViewModal
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var patientlist = findViewById<Button>(R.id.viewpatientlist)
        var patientregis = findViewById<Button>(R.id.patientregistration)

        patientlist.setOnClickListener{
            val intent = Intent(this, PatientList::class.java)
            startActivity(intent)
        }
        patientregis.setOnClickListener{
            val intent = Intent(this, AddPatient::class.java)
            startActivity(intent)
        }


    }
    fun openDialog() {
        val dialog = Dialog(this)
        var patientgendereditb: String = ""
        dialog.setContentView(R.layout.addpatient)
        dialog.window?.setLayout(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT)
        val radioGroupGender = dialog.findViewById<RadioGroup>(R.id.genderedit)

        // Set up the radio group listener to capture the selected gender
        radioGroupGender.setOnCheckedChangeListener { _, checkedId ->
            val selectedRadioButton = dialog.findViewById<RadioButton>(checkedId)
            patientgendereditb = selectedRadioButton.text.toString()
        }
        //View components on the dialog box
        val cancelbu = dialog.findViewById<Button>(R.id.cancelbutton)
        val addbu = dialog.findViewById<Button>(R.id.add)
        val patientnameeditb = dialog.findViewById<EditText>(R.id.patientnameedit)
        val patientageeditb = dialog.findViewById<EditText>(R.id.patientageedit)
       /** val patientgendereditb = dialog.findViewById<EditText>(R.id.genderedit)*/
        val bloodgroupeditb =  findViewById<Spinner>(R.id.bloodgroupedit)
        if (bloodgroupeditb != null) {
            val adapter = ArrayAdapter.createFromResource(this, R.array.BloodGroupselection, android.R.layout.simple_spinner_item)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            bloodgroupeditb.adapter = adapter

            // ... (rest of the code)
        } else {
            Log.e("SpinnerError", "Spinner with ID R.id.bloodgroupedit not found")
        }

        //Initialising cancel buttons
        cancelbu.setOnClickListener {
            dialog.dismiss()

        }

        //Initialising add button
        addbu.setOnClickListener {
            val PatientName: String = patientnameeditb.text.toString()
            val PatientAge: String = patientageeditb.text.toString()
            val PatientGender: String = patientgendereditb
            val BloodGroup: String = bloodgroupeditb.selectedItem.toString()
            val age: Int = PatientAge.toInt()
            val gend: String = PatientGender
            val bg: String = BloodGroup
            if (PatientName.isNotEmpty() && PatientAge.isNotEmpty() && PatientGender.isNotEmpty() && BloodGroup.isNotEmpty()) {
                val items = Patientlist(PatientName, age, gend, bg)
                patientViewModal.insertitem(items)
                Toast.makeText(
                    applicationContext,
                    "Patient inserted successfully...",
                    Toast.LENGTH_SHORT
                ).show()
                patientRecyclerAdaptor.notifyDataSetChanged()
                dialog.dismiss()
            }
            else{
                Toast.makeText(applicationContext,"Please enter all of the details....",Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()

    }

    override fun onScanCompleted(deviceDataList: BleDeviceData) {
        TODO("Not yet implemented")
    }

    /**
     * Check the Location Permission before calling the BLE API's
     */
}


