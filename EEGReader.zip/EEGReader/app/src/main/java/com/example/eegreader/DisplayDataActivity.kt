package com.example.eegreader

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DisplayDataActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sensoroutput)

        // Retrieve the data array from the intent
        val dataArray = intent.getDoubleArrayExtra("dataArray")

        // Update your UI components with the received data array
        dataArray?.let { displayDataInUI(it) }
    }

    private fun displayDataInUI(dataArray: DoubleArray) {
        val phaseAngleTextView = findViewById<TextView>(R.id.phaseAngleTextView)
        val bioImpedanceTextView = findViewById<TextView>(R.id.bioImpedanceTextView)
        val frequencyTextView = findViewById<TextView>(R.id.frequencyTextView)

        // Assuming the dataArray contains phase angle, bioimpedance, and frequency in that order
        if (dataArray.size >= 3) {
            val phaseAngle = dataArray[0]
            val bioImpedance = dataArray[1]
            val frequency = dataArray[2]

            phaseAngleTextView.text = "Phase Angle: $phaseAngle"
            bioImpedanceTextView.text = "Bioimpedance: $bioImpedance"
            frequencyTextView.text = "Frequency: $frequency"
        }
    }
}
