package com.example.eegreader

import android.app.Service.START_NOT_STICKY
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.eegreader.StatusDB.StatusViewModal
import com.example.eegreader.database.PatientDatabase
import com.example.eegreader.database.PatientRepository
import com.example.eegreader.database.PatientViewModal
import com.example.eegreader.database.PatientViewModalFactory
import com.example.eegreader.database.StatusDatabase
import com.example.eegreader.database.StatusRepository
import com.example.eegreader.database.StatusViewModalFactory
import java.util.UUID

class SensorOutput : AppCompatActivity() {
    private lateinit var frequencyTextView: TextView
    private lateinit var bioImpedanceTextView: TextView
    private lateinit var phaseAngleTextView: TextView
private lateinit var dataArray: ArrayList<Double>
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.eegreader.ACTION_DATA") {
                val dataValueList = intent.getSerializableExtra("dataValueNew") as? ArrayList<Double>
                dataValueList?.let {
                    updateUI(it)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sensoroutput)

        frequencyTextView = findViewById(R.id.frequencyTextView)
        bioImpedanceTextView = findViewById(R.id.bioImpedanceTextView)
        phaseAngleTextView = findViewById(R.id.phaseAngleTextView)

        val statusRepository = StatusRepository(StatusDatabase(this))
        val factory = StatusViewModalFactory(statusRepository)

        // Creating the ViewModel using the factory
        val statusViewModal = ViewModelProvider(this, factory).get(StatusViewModal::class.java)
       /* dataArray =
            (intent?.getSerializableExtra("dataValueNew") as? ArrayList<Double>)!!
        Log.d("array","${dataArray}")
        updateUI(dataArray)*/
        // Observing the data from the ViewModel
       /* statusViewModal.getthelistofstatus().observe(this, { statusList ->
            // statusList contains the data from the database
            Log.d("here","${statusList}")
            if (statusList.isNotEmpty()) {
                Log.d("I am here","hello")
                val latestStatus = statusList.last() // Assuming you want to display the latest entry
                val dataValueList = arrayListOf(
                    latestStatus.frequency,
                    latestStatus.phaseangle,
                    latestStatus.timeperiod
                )
                updateUI(dataValueList)
            }
        })*/
        val dataArrayFromIntent = intent?.getSerializableExtra("dataValueNew") as? ArrayList<Double>
        Log.d("array", "$dataArrayFromIntent")
        if (dataArrayFromIntent != null) {
            dataArray = dataArrayFromIntent

            updateUI(dataArray)
        }}
    fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dataArrayFromIntent = intent?.getSerializableExtra("dataValueNew") as? ArrayList<Double>
        Log.d("array", "$dataArrayFromIntent")
        if (dataArrayFromIntent != null) {
            dataArray = dataArrayFromIntent

            updateUI(dataArray)
        }
        // ... other code
        return START_NOT_STICKY
    }

    // ... other member functions





    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver)
    }

    private fun updateUI(dataValueList: ArrayList<Double>) {
        frequencyTextView.text = dataValueList[0].toString()

        Log.d("I am in","${dataValueList[0]}")
        bioImpedanceTextView.text = dataValueList[1].toString()
        phaseAngleTextView.text = dataValueList[2].toString()

    }
}
