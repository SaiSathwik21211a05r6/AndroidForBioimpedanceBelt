package com.example.eegreader.RecyclerView

//Importing necessary views for recycler view
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

//Importing files for view components
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity

//importing recycler view package
import androidx.recyclerview.widget.RecyclerView
import com.example.eegreader.AddPatient
import com.example.eegreader.PatientList
import com.example.eegreader.R
import com.example.eegreader.database.Patientlist
import android.content.Intent
import android.widget.Button
import com.example.eegreader.RecordScreen


//Creating an adaptor class
class PatientRecyclerAdaptor(
    var list: List<Patientlist>,
    val patientListClickInterface: PatientListClickInterface
):RecyclerView.Adapter<PatientRecyclerAdaptor.PatientViewHolder>() {

    //View holder in recycler view
    inner class PatientViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        //Initialising view components on each element in the recycler view
        val patientnamea = itemView.findViewById<TextView>(R.id.patientname)
        val agea = itemView.findViewById<TextView>(R.id.Age)
        val gendera = itemView.findViewById<TextView>(R.id.Gender)
        val bloodgroupa = itemView.findViewById<TextView>(R.id.BloodGroup)
        /**val deletebuttona = itemView.findViewById<ImageView>(R.id.Deletebutton)
*/ val deletebuttona = itemView.findViewById<Button>(R.id.Deleterecycbutton)
        val recordbuttona=itemView.findViewById<Button>(R.id.Deletebutton)



    }


    interface PatientListClickInterface {
        fun OnItemClick(patientlist: Patientlist)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PatientViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.patientlistrecycler, parent, false)
        return PatientViewHolder(view)
    }

    override fun onBindViewHolder(holder: PatientViewHolder, position: Int) {
        holder.patientnamea.text = list.get(position).patientName
        holder.agea.text = list.get(position).patientAge.toString()
        holder.gendera.text =  list.get(position).patientGender.toString()
        holder.bloodgroupa.text = list.get(position).patientBg.toString()
        holder.deletebuttona.setOnClickListener {
            patientListClickInterface.OnItemClick(list.get(position))

        }
        holder.recordbuttona.setOnClickListener {
            val intent = Intent(holder.itemView.context, RecordScreen::class.java)
            holder.itemView.context.startActivity(intent)
        }
    }




    override fun getItemCount(): Int {

        return list.size
    }
}