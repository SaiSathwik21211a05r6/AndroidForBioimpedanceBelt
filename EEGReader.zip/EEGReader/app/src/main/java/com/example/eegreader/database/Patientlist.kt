package com.example.eegreader.database


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="grocery_items")
data class Patientlist(
    //Creating Name column

    @ColumnInfo(name = "patientName")
    var patientName: String,

    //Creating quantity column
    @ColumnInfo(name = "PatientAge")
    var patientAge: Int,

    //Creating price column
    @ColumnInfo(name = "Gender")
    var patientGender: String,
    @ColumnInfo(name = "BloodGroup")
    val patientBg: String,

    ){

    @PrimaryKey(autoGenerate = true)
    var id:Int?=null
}