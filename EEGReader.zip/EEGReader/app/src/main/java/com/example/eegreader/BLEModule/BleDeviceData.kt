package com.example.eegreader.BLEModule

class BleDeviceData {

    var mDeviceName : String = ""
    var mDeviceAddress : String = ""
}
