package com.example.eegreader.StatusDB

//Imports necessary for the view model class
import androidx.lifecycle.ViewModel
import com.example.eegreader.database.StatusList
import com.example.eegreader.database.StatusRepository
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

//Creating a view model class
class StatusViewModal(private val repository: StatusRepository):ViewModel() {

    //Inserted groceries
    fun insertStatus(items: StatusList)=GlobalScope.launch{
        repository.insertStatus(items)
    }

    //Deleted groceries
    fun deleteitem(items:StatusList)=GlobalScope.launch{
        repository.deleteitem(items)
    }

    //List of groceries
    fun getthelistofstatus()=repository.getthelistofstatus()

    companion object {
        fun insertitems(items: StatusList) {

        }
    }


}