package com.example.eegreader.database


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="status")
data class StatusList(
    //Creating Name column

    @ColumnInfo(name = "Patient Id")
    var patientId: Int,

    //Creating quantity column
    @ColumnInfo(name = "Frequency")
    var frequency: Double,

    //Creating price column
    @ColumnInfo(name = "Phase Angle")
    var phaseangle: Double,
    @ColumnInfo(name = "Time Period")
    val timeperiod: Double,

    ){

    @PrimaryKey(autoGenerate = true)
    var id:Int?=null
}