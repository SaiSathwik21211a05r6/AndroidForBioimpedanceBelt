package com.example.eegreader


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.eegreader.RecyclerView.PatientRecyclerAdaptor
import com.example.eegreader.database.*
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AddPatient: AppCompatActivity(),PatientRecyclerAdaptor.PatientListClickInterface {

    lateinit var itemsRV: RecyclerView
    lateinit var add: FloatingActionButton
    lateinit var list:List<Patientlist>
    lateinit var patientRecyclerAdaptor: PatientRecyclerAdaptor
    lateinit var patientViewModal: PatientViewModal
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.addpatient)
        list = ArrayList<Patientlist>()
        patientRecyclerAdaptor = PatientRecyclerAdaptor(list, this)

        val groceryRepository = PatientRepository(PatientDatabase(this))
        val factory = PatientViewModalFactory(groceryRepository)
       patientViewModal = ViewModelProvider(this, factory).get(PatientViewModal::class.java)
            var patientgendereditb: String = ""
             val radioGroupGender = findViewById<RadioGroup>(R.id.genderedit)

            // Set up the radio group listener to capture the selected gender
            radioGroupGender.setOnCheckedChangeListener { _, checkedId ->
                val selectedRadioButton = findViewById<RadioButton>(checkedId)
                patientgendereditb = selectedRadioButton.text.toString()
            }
            //View components on the dialog box
            val cancelbu = findViewById<Button>(R.id.add)
            val addbu = findViewById<Button>(R.id.cancelbutton)
            val patientnameeditb = findViewById<EditText>(R.id.patientnameedit)
            val patientageeditb = findViewById<EditText>(R.id.patientageedit)
            /** val patientgendereditb = dialog.findViewById<EditText>(R.id.genderedit)*/
            val bloodgroupeditb =  findViewById<Spinner>(R.id.bloodgroupedit)
            if (bloodgroupeditb != null) {
                val adapter = ArrayAdapter.createFromResource(this, R.array.BloodGroupselection, android.R.layout.simple_spinner_item)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                bloodgroupeditb.adapter = adapter

                // ... (rest of the code)
            } else {
                Log.e("SpinnerError", "Spinner with ID R.id.bloodgroupedit not found")
            }

            //Initialising cancel buttons
            /**cancelbu.setOnClickListener {
                dialog.dismiss()

            }*/
        cancelbu.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

            //Initialising add button
            addbu.setOnClickListener {
                val PatientName: String = patientnameeditb.text.toString()
                val PatientAge: String = patientageeditb.text.toString()
                val PatientGender: String = patientgendereditb
                val BloodGroup: String = bloodgroupeditb.selectedItem.toString()

addbu.setOnClickListener {
                if (PatientName.isNotEmpty() && PatientAge.isNotEmpty() && PatientGender.isNotEmpty() && BloodGroup.isNotEmpty()) {
                    val age: Int = PatientAge.toInt()
                    val gend: String = PatientGender
                    val bg: String = BloodGroup
                    val items = Patientlist(PatientName, age, gend, bg)
                    patientViewModal.insertitem(items)
                    Toast.makeText(
                        applicationContext,
                        "Patient inserted successfully...",
                        Toast.LENGTH_SHORT
                    ).show()
                    val intent = Intent(this, RecordScreen::class.java)
                    startActivity(intent)

                }
                else{
                    Toast.makeText(applicationContext,"Please enter all of the details....", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, AddPatient::class.java)
                    startActivity(intent)}}

            }


        }
    override fun OnItemClick(grocerylist: Patientlist) {
        patientViewModal.deleteitem(grocerylist)
        patientRecyclerAdaptor.notifyDataSetChanged()

        Toast.makeText(applicationContext,"Grocery removed successfully",Toast.LENGTH_SHORT).show()
    }
        /**
         * Check the Location Permission before calling the BLE API's
         */
    }



