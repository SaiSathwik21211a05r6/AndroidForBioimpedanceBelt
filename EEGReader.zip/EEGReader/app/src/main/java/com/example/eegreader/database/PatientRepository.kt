package com.example.eegreader.database

//Creating the repository for the grocery database
class PatientRepository(private val db:PatientDatabase) {

    //Function for adding new grocery
    suspend fun insertitem(items:Patientlist)=db.getEEGPatientDao().insertitem(items)

    //Function for deleting a grocery
    suspend fun deleteitem(items:Patientlist)=db.getEEGPatientDao().deleteitem(items)

    //Function to get the list of groceries
    fun getthelistofpatients()=db.getEEGPatientDao().getthelistofgrocery()
}