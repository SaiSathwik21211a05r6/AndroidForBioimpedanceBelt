package com.example.eegreader
/**import android.hardware.usb.UsbDevice
import android.os.Handler
import android.text.method.ScrollingMovementMethod
import android.widget.TextView
import me.aflak.arduino.Arduino
import me.aflak.arduino.ArduinoListener

class ArduinoCommunication(private val displayTextView: TextView) : ArduinoListener {
    private val arduino: Arduino
    fun onStart() {
        arduino.setArduinoListener(this)
    }

    fun onDestroy() {
        arduino.unsetArduinoListener()
        arduino.close()
    }

    fun sendMessage(message: String) {
        arduino.send(message.toByteArray())
    }

    fun onArduinoAttached(device: UsbDevice?) {
        display("Arduino attached...")
        arduino.open(device)
    }

    fun onArduinoDetached() {
        display("Arduino detached.")
    }

    fun onArduinoMessage(bytes: ByteArray?) {
        display(String(bytes!!))
    }

    fun onArduinoOpened() {
        val str = "Arduino opened..."
        arduino.send(str.toByteArray())
    }

    fun onUsbPermissionDenied() {
        display("Permission denied. Attempting again in 3 sec...")
        Handler().postDelayed({ arduino.reopen() }, 3000)
    }

    private fun display(message: String) {
        displayTextView.post { displayTextView.append(message) }
    }

    init {
        displayTextView.movementMethod = ScrollingMovementMethod()
        arduino = Arduino(displayTextView.context)
    }
}*/