package com.example.eegreader




import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity




import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.bluetooth.*
import android.bluetooth.BluetoothGattCharacteristic.*
import com.example.eegreader.BLEModule.BLEConstants
import com.example.eegreader.BLEModule.BleDeviceData
import com.example.eegreader.BLEModule.OnDeviceScanListener
import androidx.core.content.ContextCompat
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice


import android.content.Context
import android.content.Intent


import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator




import timber.log.Timber
import android.app.AlertDialog


import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.content.BroadcastReceiver


import android.content.Context.*


import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import androidx.core.app.ActivityCompat


import android.util.Log
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat.getSystemService
import com.example.eegreader.BLEModule.*
import com.np.lekotlin.blemodule.BLEConnectionManager
import com.np.lekotlin.blemodule.BLEDeviceManager

import java.nio.ByteBuffer


import java.util.*
import kotlin.collections.ArrayList
import kotlin.properties.Delegates


class RecordScreen : AppCompatActivity(), OnDeviceScanListener, View.OnClickListener {

    private lateinit var FreqStart: String
    private lateinit var FreqEnd: String
    private lateinit var FreqStep: String
    private lateinit var TimeFrame: String
    private lateinit var mBtnReadConnectionChar: Button
private var freqstarteditb by Delegates.notNull<Double>()
    private var freqendeditb by Delegates.notNull<Double>()
    private var freqstepeditb by Delegates.notNull<Double>()
    private var timeframeeditb by Delegates.notNull<Double>()

    /** private lateinit var mBtnReadBatteryLevel: Button
    private lateinit var mBtnReadEmergency: Button
    private lateinit var mBtnWriteEmergency: Button
    private lateinit var mBtnWriteConnection: Button
    private lateinit var mBtnWriteBatteryLevel: Button
    private lateinit var mTvResult: TextView*/

private lateinit var dataArray:ArrayList<Double>
    private var mDeviceAddress: String = ""
    private val ENABLE_BLUETOOTH_REQUEST_CODE = 1
    private val RUNTIME_PERMISSION_REQUEST_CODE = 2
    override fun onScanCompleted(deviceDataList: BleDeviceData) {
        val bluetoothAddressPattern = "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$".toRegex()


        if (deviceDataList.mDeviceAddress.matches(bluetoothAddressPattern)) {
            mDeviceAddress = deviceDataList.mDeviceAddress
            BLEConnectionManager.connect(deviceDataList.mDeviceAddress)
        } else {
            Log.e(TAG, "Invalid Bluetooth address: ${deviceDataList.mDeviceAddress}")
        }
    }


    /* private val scanResultAdapter: ScanResultAdapter by lazy {
         ScanResultAdapter(scanResults) { result ->
             // User tapped on a scan result
             if (isScanning) {
                 stopBleScan()
             }
             with(result.device) {
                 Log.w("ScanResultAdapter", "Connecting to $address")
                 connectGatt(context, false, gattCallback)
             }
         }
     }*/
   /* private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val deviceAddress = gatt.device.address


            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.w("BluetoothGattCallback", "Successfully connected to $deviceAddress")
                    // TODO: Store a reference to BluetoothGatt
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.w("BluetoothGattCallback", "Successfully disconnected from $deviceAddress")
                    gatt.close()
                }
            } else {
                Log.w(
                    "BluetoothGattCallback",
                    "Error $status encountered for $deviceAddress! Disconnecting..."
                )
                gatt.close()
            }
        }
    }*/
    private val REQUEST_LOCATION_PERMISSION = 2018
    private val TAG = "RecordScreen"
    private val REQUEST_ENABLE_BT = 1000
    private val bluetoothAdapter: BluetoothAdapter by lazy {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }


    private val bleScanner by lazy {
        bluetoothAdapter.bluetoothLeScanner
    }


    // From the previous section:


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.recordscreen)


        var commchanneditb: String = ""
        val radioGroupCommChann = findViewById<RadioGroup>(R.id.commchannedit)


        // Set up the radio group listener to capture the selected gender
        radioGroupCommChann.setOnCheckedChangeListener { _, checkedId ->
            val selectedRadioButton = findViewById<RadioButton>(checkedId)
            commchanneditb = selectedRadioButton.text.toString()
        }
        val cancelbu = findViewById<Button>(R.id.record)
        val addbu = findViewById<Button>(R.id.sweep)
        val freqstarteditb = findViewById<EditText>(R.id.freqstartedit)
        val freqendeditb = findViewById<EditText>(R.id.freqendedit)

        /** val patientgendereditb = dialog.findViewById<EditText>(R.id.genderedit)*/
        val freqstepeditb = findViewById<EditText>(R.id.freqstepedit)
        val timeframeeditb = findViewById<EditText>(R.id.timeframeedit)
        mBtnReadConnectionChar = findViewById<Button>(R.id.record)
        /**  mBtnReadEmergency = findViewById(R.id.btn_read_emergency)
        mBtnReadBatteryLevel = findViewById(R.id.btn_read_battery)
        mBtnWriteEmergency = findViewById(R.id.btn_write_emergency)
        mBtnWriteConnection = findViewById<Button>(R.id.btn_write_connection)
        mBtnWriteBatteryLevel = findViewById(R.id.btn_write_battery)
        mTvResult = findViewById(R.id.tv_result)**/


        findViewById<View>(R.id.sweep).setOnClickListener(this)
        mBtnReadConnectionChar.setOnClickListener(this)




             dataArray = ArrayList()





 // Convert input strings to integers or doubles
            /* val freqStartValue: Double = FreqStart.toDouble()
             val freqEndValue: Double = FreqEnd.toDouble()
             val freqStepValue: Double = FreqStep.toDouble()
             val timeFrameValue: Double = TimeFrame.toDouble()
             dataArray.add(freqStartValue)
             dataArray.add(freqEndValue)
             dataArray.add(freqStepValue)
             dataArray.add(timeFrameValue)*/
 // Create an array to store the values


          /*   val characteristicUuidString = "00002a19-0000-1000-8000-00805f9b34fb"
             val characteristicUuid: UUID = UUID.fromString(characteristicUuidString)
             onClick(mBtnReadConnectionChar)
             sendArrayToBLEService(dataArray,characteristicUuid)
         }*/


        /**mBtnWriteEmergency.setOnClickListener(this)


        mBtnReadEmergency.setOnClickListener(this)
        mBtnReadBatteryLevel.setOnClickListener(this)


        mBtnWriteBatteryLevel.setOnClickListener(this)
        mBtnWriteConnection.setOnClickListener(this)*/


        checkLocationPermission()
    }

    private val scanSettings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .build()

    private val scanCallback = object : ScanCallback() {

        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
Log.d("h","${dataArray}")
            Log.d("hello", "Checking device name: " + result.device.name);
            if (result.device.name?.trim() == "=BLEMED"&&isValidBluetoothAddress(result.device.address)) {
                // Initiate connection
                Log.d("hello", "onScanResult: Device found")

                connectDevice(result.device.address)

            }
        }


        override fun onScanFailed(errorCode: Int) {
            Log.d("ScanCallback", "onScanFailed: code $errorCode")
            when (errorCode) {
                ScanCallback.SCAN_FAILED_ALREADY_STARTED -> {
                    Log.e("ScanCallback", "Scan already started")
                }
                ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED -> {
                    Log.e("ScanCallback", "Scan registration failed")
                }
                // Handle other error codes
                // ...
            }
        }
    }
    private fun isValidBluetoothAddress(address: String?): Boolean {
        if (address == null) {
            return false
        }

        val addressPattern = "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$"
        val reversedAddressPattern = "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$"
        return address.matches(Regex(addressPattern)) || address.matches(Regex(reversedAddressPattern))
    }






    @SuppressLint("MissingPermission")
    private fun startBLEScan() {
        if (!hasRequiredRuntimePermissions()) {


            requestRelevantRuntimePermissions()
        } else {
            Toast.makeText(this, "Hello", Toast.LENGTH_SHORT).show()

            bleScanner.startScan(null, scanSettings, scanCallback)
            Log.d("he","${dataArray}")
            // No need for handler.postDelayed to stop the scan immediately

            // You can optionally add a toast message to indicate that scanning has started
            Toast.makeText(this, "Scanning started", Toast.LENGTH_SHORT).show()

        }
    }


    /**
     * Check the Location Permission before calling the BLE API's
     */
    private fun checkLocationPermission() {
        if (isAboveMarshmallow()) {
            when {
                isLocationPermissionEnabled() -> initBLEModule()
                ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) -> displayRationale()
                else -> requestLocationPermission()
            }
        } else {
            initBLEModule()
        }
    }


    /**
     * Request Location API
     * If the request go to Android system and the System will throw a dialog message
     * user can accept or decline the permission from there
     */




    /**
     * If the user decline the Permission request and tick the never ask again message
     * Then the application can't proceed further steps
     * In such situation- App need to prompt the user to do the change form Settings Manually
     */
    private fun displayRationale() {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.location_permission_disabled))
            .setPositiveButton(getString(R.string.ok)
            ) { _, _ -> requestLocationPermission() }
            .setNegativeButton(getString(R.string.cancel)
            ) { _, _ -> }
            .show()
    }


    /**
     * If the user either accept or reject the Permission- The requested App will get a callback
     * Form the call back we can filter the user response with the help of request key
     * If the user accept the same- We can proceed further steps
     */
    @SuppressLint("MissingSuperCall")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>,
                                            grantResults: IntArray) {
        when (requestCode) {
            REQUEST_LOCATION_PERMISSION -> {
                if (permissions.size != 1 || grantResults.size != 1) {
                    throw RuntimeException("Error on requesting location permission.")
                }
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initBLEModule()
                } else {
                    Toast.makeText(this, R.string.location_permission_not_granted,
                        Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    /**
     * Check with the system- If the permission already enabled or not
     */
    private fun isLocationPermissionEnabled(): Boolean {
        return ContextCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }


    /**
     * The location permission is incorporated in Marshmallow and Above
     */
    private fun isAboveMarshmallow(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
    }




    /**
     *After receive the Location Permission, the Application need to initialize the
     * BLE Module and BLE Service
     */
    @SuppressLint("MissingPermission")
    private fun initBLEModule() {
        // BLE initialization
        if (!BLEDeviceManager.init(this)) {
            Toast.makeText(this, "BLE NOT SUPPORTED", Toast.LENGTH_SHORT).show()
            return
        }
        registerServiceReceiver()
        BLEDeviceManager.setListener(this)


        if (!BLEDeviceManager.isEnabled()) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
        }


        BLEConnectionManager.initBLEService(this)
    }




    /**
     * Register GATT update receiver
     */
    private fun registerServiceReceiver() {
        this.registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter())
    }






    private val mGattUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            when {
                BLEConstants.ACTION_GATT_CONNECTED.equals(action) -> {
                    Log.i(TAG, "ACTION_GATT_CONNECTED ")
                    BLEConnectionManager.findBLEGattService(this@RecordScreen)
                }
                BLEConstants.ACTION_GATT_DISCONNECTED.equals(action) -> {
                    Log.i(TAG, "ACTION_GATT_DISCONNECTED ")
                }
                BLEConstants.ACTION_GATT_SERVICES_DISCOVERED.equals(action) -> {
                    Log.i(TAG, "ACTION_GATT_SERVICES_DISCOVERED ")
                    try {
                        Thread.sleep(500)
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }
                    BLEConnectionManager.findBLEGattService(this@RecordScreen)
                }
                BLEConstants.ACTION_DATA_AVAILABLE.equals(action) -> {
                    val data = intent.getStringExtra(BLEConstants.EXTRA_DATA)
                    val uuId = intent.getStringExtra(BLEConstants.EXTRA_UUID)
                    Log.i(TAG, "ACTION_DATA_AVAILABLE $data")


                }
                BLEConstants.ACTION_DATA_WRITTEN.equals(action) -> {
                    val data = intent.getStringExtra(BLEConstants.EXTRA_DATA)
                    Log.i(TAG, "ACTION_DATA_WRITTEN ")
                }
            }
        }


    }


    /**
     * Intent filter for Handling BLEService broadcast.
     */
    private fun makeGattUpdateIntentFilter(): IntentFilter {
        val intentFilter = IntentFilter()
        intentFilter.addAction(BLEConstants.ACTION_GATT_CONNECTED)
        intentFilter.addAction(BLEConstants.ACTION_GATT_DISCONNECTED)
        intentFilter.addAction(BLEConstants.ACTION_GATT_SERVICES_DISCOVERED)
        intentFilter.addAction(BLEConstants.ACTION_DATA_AVAILABLE)
        intentFilter.addAction(BLEConstants.ACTION_DATA_WRITTEN)


        return intentFilter
    }


    /**
     * Unregister GATT update receiver
     */
    private fun unRegisterServiceReceiver() {
        try {
            this.unregisterReceiver(mGattUpdateReceiver)
        } catch (e: Exception) {
            //May get an exception while user denies the permission and user exists the app
            Log.e(TAG, e.message.toString())
        }


    }


    override fun onDestroy() {
        super.onDestroy()
        BLEConnectionManager.disconnect()
        unRegisterServiceReceiver()
    }


    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.record -> {if (!BLEDeviceManager.isEnabled()) {
                // Bluetooth is not enabled, prompt the user to enable it
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
                checkLocationPermission() } else {

               /* dataArray.add(freqStartValue)
                dataArray.add(freqEndValue)
                dataArray.add(freqStepValue)
                dataArray.add(timeFrameValue)*/

                // Bluetooth is already enabled, you can proceed with BLE device scanning

                dataArray.add(freqstarteditb)
                dataArray.add(freqendeditb)
                dataArray.add(freqstepeditb)
                dataArray.add(timeframeeditb)
                    startBLEScan()




            }
            }
            R.id.sweep ->
                readMissedConnection()
            /**R.id.btn_read_battery ->
            readBatteryLevel()*/


            /**R.id.btn_read_emergency ->
            readEmergencyGatt()*/


            /**R.id.btn_write_emergency ->
            writeEmergency()


            R.id.btn_write_battery ->
            writeBattery()


            R.id.btn_write_connection ->
            writeMissedConnection()
             **/
        }
    }


    private fun writeEmergency() {
        BLEConnectionManager.writeEmergencyGatt("0xfe");
    }


    private fun writeBattery() {
        BLEConnectionManager.writeBatteryLevel("100")
    }


    private fun writeMissedConnection() {
        BLEConnectionManager.writeMissedConnection("0x00")
    }


    private fun readMissedConnection() {
       // BLEConnectionManager.readMissedConnection(getString(R.string.char_uuid_missed_calls), this@RecordScreen)
    }


    private fun readBatteryLevel() {
        BLEConnectionManager.readBatteryLevel(getString(R.string.char_uuid_emergency))
    }


    private fun readEmergencyGatt() {
        BLEConnectionManager.readEmergencyGatt(getString(R.string.char_uuid_emergency))
    }


    /**
     * Scan the BLE device if the device address is null
     * else the app will try to connect with device with existing device address.
     */
    /*private fun scanDevice(isContinuesScan: Boolean) {
        if (!mDeviceAddress.isNullOrEmpty()) {
            //connectDevice()
        } else {
            BLEDeviceManager.scanBLEDevice(isContinuesScan)
        }
    }




    /*private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            if (newState == BluetoothGatt.STATE_CONNECTED) {
                gatt?.requestMtu(256)
                gatt?.discoverServices()
            }
        }
    }*/




    fun scanForDevices (context: Context) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        adapter.bluetoothLeScanner.startScan(callback)


    }





*/
    private val bluetoothLeScanner=BluetoothAdapter.getDefaultAdapter().bluetoothLeScanner
    private var scanning = false
    private val handler = Handler()

/*
    // Stops scanning after 10 seconds.
    private val SCAN_PERIOD: Long = 10000
    private fun scanLeDevice() { if (!scanning) {






        // Stops scanning after a pre-defined scan period.
        handler.postDelayed({scanning = false
            bluetoothLeScanner.stopScan(callback) }, SCAN_PERIOD)
        scanning = true
        bluetoothLeScanner?.startScan(callback)}
    else { scanning = false
        bluetoothLeScanner.stopScan(callback) }}
    private val callback= object: ScanCallback() {
        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { result -> deviceFound (result.device)
            }}   override fun onScanResult(callbackType: Int, result: ScanResult?) { Toast.makeText(this@RecordScreen,"No Device Found",Toast.LENGTH_SHORT).show()
            Toast.makeText(this@RecordScreen,"No Device Found",Toast.LENGTH_SHORT).show()
            result?.let {(deviceFound(result.device))}
        }     override fun onScanFailed(errorCode: Int) {




            Toast.makeText(this@RecordScreen,"No Device Found",Toast.LENGTH_SHORT).show()


        } private fun deviceFound(device: BluetoothDevice) {
            Toast.makeText(this@RecordScreen,"No Device Found",Toast.LENGTH_SHORT).show()
            device.connectGatt(this@RecordScreen, true, gattCallback)
            connectDevice(device.address)
        }
    }*/


    /**
     * Connect the application with BLE device with selected device address.
     */
    private fun connectDevice(deviceAddress: String) {
        Handler().postDelayed({
            BLEConnectionManager.initBLEService(this)
            if (BLEConnectionManager.connect(deviceAddress)) {
                Toast.makeText(this, "DEVICE CONNECTED", Toast.LENGTH_SHORT).show()
                 // Create your data array
                val characteristicUuid: UUID = UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB")
                /*val characteristicUuid: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")*/
                sendArrayToBLEService(dataArray, characteristicUuid,deviceAddress)
            } else {
                Toast.makeText(this, "DEVICE CONNECTION FAILED", Toast.LENGTH_SHORT).show()
            }
        }, 100)


    }

    private fun sendArrayToBLEService(dataArray: ArrayList<Double>, characteristicUuid: UUID,deviceAddress:String) {
        /** scanDevice(true)
        connectDevice()*/


        val bleServiceIntent = Intent(this, BLEService::class.java)
        bleServiceIntent.putExtra("characteristicUuid", characteristicUuid)
        Log.d("RecScreen","${dataArray}")
        bleServiceIntent.putExtra("dataArray", dataArray)
        bleServiceIntent.putExtra("deviceAddress", deviceAddress)
        startService(bleServiceIntent)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            ENABLE_BLUETOOTH_REQUEST_CODE -> {
                if (resultCode != RESULT_OK) {
                    promptEnableBluetooth()
                }
            }
        }
    }



    // Callback for BluetoothGattCallback
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // Loop through services
                for (service in gatt?.services.orEmpty()) {
                    // Loop through characteristics within the service
                    for (characteristic in service.characteristics) {
                        // Handle the characteristic as needed
                        // For example, send data to the characteristic
                        sendDataToCharacteristic(characteristic)
                    }
                }
            }
        }
    }

    private fun sendDataToCharacteristic(characteristic: BluetoothGattCharacteristic) {
        val dataArray: ArrayList<Double> = ArrayList()
        // Create your data array
        val bleServiceIntent = Intent(this, BLEService::class.java)
        bleServiceIntent.putExtra("characteristicUuid", characteristic.uuid.toString())
        bleServiceIntent.putExtra("dataArray", dataArray)
        startService(bleServiceIntent)
    }



    override fun onResume() {
        super.onResume()
        if (!bluetoothAdapter.isEnabled) {
            promptEnableBluetooth()
        }
    }


    @SuppressLint("MissingPermission")
    private fun promptEnableBluetooth() {
        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, ENABLE_BLUETOOTH_REQUEST_CODE)
        }
    }
    private fun Activity.requestRelevantRuntimePermissions() {
        if (hasRequiredRuntimePermissions()) { return }
        when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S -> {
                requestLocationPermission()
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                requestBluetoothPermissions()
            }
        }
    }
    fun Context.hasPermission(permissionType: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permissionType) ==
                PackageManager.PERMISSION_GRANTED
    }
    fun Context.hasRequiredRuntimePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hasPermission(Manifest.permission.BLUETOOTH_SCAN) &&
                    hasPermission(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
    /* private fun startBleScan() {
         if (!hasRequiredRuntimePermissions()) {
             requestRelevantRuntimePermissions()
         } else { /* TODO: Actually perform scan */ }
     }*/



    private fun requestLocationPermission() {
        val permission = Manifest.permission.ACCESS_FINE_LOCATION
        val rationale = "Starting from Android 12, the app needs location access to scan for BLE devices."
        val PERMISSION_REQUEST_CODE = 123 // Replace 123 with any unique integer value

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            // Permission is already granted, no need to show the dialog
            // You can proceed with your logic here
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                // Show an explanation dialog if needed
                val alertDialogBuilder = AlertDialog.Builder(this)
                alertDialogBuilder.apply {
                    setTitle("Location permission required")
                    setMessage(rationale)
                    setCancelable(false)
                    setPositiveButton(android.R.string.ok) { _, _ ->
                        // Request the permission using the appropriate API
                        ActivityCompat.requestPermissions(
                            this@RecordScreen, arrayOf(permission),
                            PERMISSION_REQUEST_CODE
                        )
                    }
                    create().show()
                }
            } else {
                // Request the permission directly, without showing an explanation
                ActivityCompat.requestPermissions(
                    this, arrayOf(permission),
                    PERMISSION_REQUEST_CODE
                )
            }
        }
    }


    private fun requestBluetoothPermissions() {
        runOnUiThread {
            val alertDialogBuilder = AlertDialog.Builder(this)
            alertDialogBuilder.apply {
                setTitle("Location permission required")
                setMessage("Starting from Android 12, the app needs location access to scan for BLE devices.")
                setCancelable(false)
                setPositiveButton(android.R.string.ok) { _, _ ->
                    requestLocationPermission()
                }
                create().show()
            }
        }
    }
    /* override fun onRequestPermissionsResult(
         requestCode: Int,
         permissions: Array<out String>,
         grantResults: IntArray
     ) {
         super.onRequestPermissionsResult(requestCode, permissions, grantResults)
         when (requestCode) {
             RUNTIME_PERMISSION_REQUEST_CODE -> {
                 val containsPermanentDenial = permissions.zip(grantResults.toTypedArray()).any {
                     it.second == PackageManager.PERMISSION_DENIED &&
                             !ActivityCompat.shouldShowRequestPermissionRationale(this, it.first)
                 }
                 val containsDenial = grantResults.any { it == PackageManager.PERMISSION_DENIED }
                 val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                 when {
                     containsPermanentDenial -> {
                         // TODO: Handle permanent denial (e.g., show AlertDialog with justification)
                         // Note: The user will need to navigate to App Settings and manually grant
                         // permissions that were permanently denied
                     }
                     containsDenial -> {
                         requestRelevantRuntimePermissions()
                     }
                     allGranted && hasRequiredRuntimePermissions() -> {
                         startBleScan()
                     }
                     else -> {
                         // Unexpected scenario encountered when handling permissions
                         recreate()
                     }
                 }
             }
         }
     }*/


}
