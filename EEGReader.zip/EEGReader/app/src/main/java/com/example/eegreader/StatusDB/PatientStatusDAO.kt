package com.example.eegreader.database


//Making necessary imports
import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

//Creating data access object for grocery database
@Dao
interface PatientStatusDao {

    //Inserting new grocery into the database
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertstatus(item: StatusList)

    //Removing grocery from the database
    @Delete
    suspend fun deletestatus(item: StatusList)

    //Creating a query
    @Query("Select * FROM status")
    fun getthelistofstatus():LiveData<List<StatusList>>
}