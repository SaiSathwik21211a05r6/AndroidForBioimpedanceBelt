package com.example.eegreader.database

//Imports necessary for the view model class
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

//Creating a view model class
class PatientViewModal(private val repository: PatientRepository):ViewModel() {

    //Inserted groceries
    fun insertitem(items:Patientlist)=GlobalScope.launch{
        repository.insertitem(items)
    }

    //Deleted groceries
    fun deleteitem(items:Patientlist)=GlobalScope.launch{
        repository.deleteitem(items)
    }

    //List of groceries
    fun getthelistofpatients()=repository.getthelistofpatients()
}