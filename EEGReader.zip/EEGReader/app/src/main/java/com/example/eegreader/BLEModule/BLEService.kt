package com.example.eegreader.BLEModule
/*
import android.app.Service
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Binder
import android.os.IBinder
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.eegreader.R
import com.np.lekotlin.blemodule.BLEConnectionManager
import java.nio.ByteBuffer
import java.util.*
import kotlin.experimental.and

class BLEService: Service() {

    private val TAG = "BLE"
    private val mBinder = LocalBinder()//Binder for Activity that binds to this Service
    private var mBluetoothManager: BluetoothManager? = null//BluetoothManager used to get the BluetoothAdapter
    private var mBluetoothAdapter: BluetoothAdapter? = null//The BluetoothAdapter controls the BLE radio in the phone/tablet
    private var mBluetoothGatt: BluetoothGatt? = null//BluetoothGatt controls the Bluetooth communication link
    private var mBluetoothDeviceAddress: String? = null//Address of the connected BLE device
    private val mCompleResponseByte = ByteArray(100)



    private val mGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {//Change in connection state

            if (newState == BluetoothProfile.STATE_CONNECTED) {//See if we are connected
                Log.i(TAG, "**ACTION_SERVICE_CONNECTED from onConnectionStateChange**$status")
                broadcastUpdate(BLEConstants.ACTION_GATT_CONNECTED)//Go broadcast an intent to say we are connected
                gatt.discoverServices()
                mBluetoothGatt?.discoverServices()//Discover services on connected BLE device
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {//See if we are not connectedLog.i(TAG, "**ACTION_SERVICE_DISCONNECTED**" + status);
                broadcastUpdate(BLEConstants.ACTION_GATT_DISCONNECTED)//Go broadcast an intent to say we are disconnected
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {              //BLE service discovery complete
            if (status == BluetoothGatt.GATT_SUCCESS) {                                 //See if the service discovery was successful
                Log.i(TAG, "**ACTION_SERVICE_DISCOVERED from onServiceDiscovered**${getSupportedGattServices()}")
                broadcastUpdate(BLEConstants.ACTION_GATT_SERVICES_DISCOVERED)                       //Go broadcast an intent to say we have discovered services
            } else {                                                                      //Service discovery failed so log a warning
                //Log.i(TAG, "onServicesDiscovered received: $status")
            }
        }

        //For information only. This application uses Indication to receive updated characteristic data, not Read
        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) { //A request to Read has completed
            //String value = characteristic.getStringValue(0);
            //int value = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT32, 0);
            val values = characteristic.value
            val clearValue = byteArrayOf(255.toByte())
            var value = 0

            if (null != values) {
              //  Log.i(TAG, "ACTION_DATA_READ VALUE: " + values.size)
                //Log.i(TAG, "ACTION_DATA_READ VALUE: " + (values[0] and 0xFF.toByte()))

                value = (values[0] and 0xFF.toByte()).toInt()
            }

            BLEConnectionManager.writeEmergencyGatt(clearValue)

            if (status == BluetoothGatt.GATT_SUCCESS) {
                //See if the read was successful
                Log.i(TAG, "**ACTION_DATA_READ from onCharacteristicRead**$characteristic")
                broadcastUpdate(BLEConstants.ACTION_DATA_AVAILABLE, characteristic)                 //Go broadcast an intent with the characteristic data
            } else {
               // Log.i(TAG, "ACTION_DATA_READ: Error$status")
            }

        }

        //For information only. This application sends small packets infrequently and does not need to know what the previous write completed
        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) { //A request to Write has completed
            if (status == BluetoothGatt.GATT_SUCCESS) {                                 //See if the write was successful
                Log.e(TAG, "**ACTION_DATA_WRITTEN from onCharacteristicWrite**$characteristic")
                broadcastUpdate(BLEConstants.ACTION_DATA_WRITTEN, characteristic)                   //Go broadcast an intent to say we have have written data
            }
            else
            {
                Log.d(TAG, "Characteristic write failed: from onCharacteristicWrite" + characteristic.getUuid() + ", Status: " + status)

            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic?) {

            if (characteristic != null && characteristic.properties == BluetoothGattCharacteristic.PROPERTY_NOTIFY) {
               // Log.e(TAG, "**THIS IS A NOTIFY MESSAGE")
            }
            if (characteristic != null) {
                broadcastUpdate(BLEConstants.ACTION_DATA_AVAILABLE, characteristic)
            }                     //Go broadcast an intent with the characteristic data
        }


    }
    // An activity has bound to this service
    override fun onBind(intent: Intent): IBinder? {

        return mBinder                                                                 //Return LocalBinder when an Activity binds to this Service
    }

    // An activity has unbound from this service
    override fun onUnbind(intent: Intent): Boolean {

        if (mBluetoothGatt != null) {                                                   //Check for existing BluetoothGatt connection
            mBluetoothGatt!!.close()                                                     //Close BluetoothGatt coonection for proper cleanup
            mBluetoothGatt = null                                                      //No longer have a BluetoothGatt connection
        }

        return super.onUnbind(intent)
    }

    fun connect(address: String?): Boolean {
        try {

            if (mBluetoothAdapter == null || address == null) {                             //Check that we have a Bluetooth adappter and device address
            //    Log.i(TAG, "BluetoothAdapter not initialized or unspecified address.")     //Log a warning that something went wrong
                return false                                                               //Failed to connect
            }

            // Previously connected device.  Try to reconnect.
            if (mBluetoothDeviceAddress != null && address == mBluetoothDeviceAddress && mBluetoothGatt != null) { //See if there was previous connection to the device
             //   Log.i(TAG, "Trying to use an existing mBluetoothGatt for connection.")
                //See if we can connect with the existing BluetoothGatt to connect
                //Success
                //Were not able to connect
                return mBluetoothGatt!!.connect()
            }

            val device = mBluetoothAdapter!!.getRemoteDevice(address)
                ?: //Check whether a device was returned
                return false                                                               //Failed to find the device
            //No previous device so get the Bluetooth device by referencing its address

            mBluetoothGatt = device.connectGatt(this, false, mGattCallback)                //Directly connect to the device so autoConnect is false
            mBluetoothDeviceAddress = address                                              //Record the address in case we need to reconnect with the existing BluetoothGatt

            return true
        } catch (e: Exception) {
          //  Log.i(TAG, e.message.toString())
        }

        return false
    }

    // Broadcast an intent with a string representing an action
    private fun broadcastUpdate(action: String) {
        val intent = Intent(action)                                       //Create new intent to broadcast the action
        sendBroadcast(intent)                                                          //Broadcast the intent
    }

    // Broadcast an intent with a string representing an action an extra string with the data
    // Modify this code for data that is not in a string format
    private fun broadcastUpdate(action: String, characteristic: BluetoothGattCharacteristic) {
        //Create new intent to broadcast the action
        val intent = Intent(action)
        var dataValueHex = ""
        var dataValueNew = ""

        val value = characteristic.value
        if (value != null) {
            for (singleData in value) {
                dataValueHex = dataValueHex + "\t" + "0x" + String.format(Locale.ENGLISH, "%02X", singleData)
                dataValueHex = dataValueHex.replace(",", ".")
                dataValueNew = "$dataValueNew $singleData"
            }
            Log.i(TAG, "MESSAGE Response Array Normal===> " + dataValueNew + " UUID " + characteristic.uuid)
            intent.putExtra(BLEConstants.EXTRA_DATA, dataValueNew)
            intent.putExtra(BLEConstants.EXTRA_UUID, characteristic.uuid)
            sendBroadcast(intent)
        }
    }

    // A Binder to return to an activity to let it bind to this service
    inner class LocalBinder : Binder(){
        internal fun getService(): BLEService {
            return this@BLEService//Return this instance of BluetoothLeService so clients can call its public methods
        }
    }

    // Enable indication on a characteristic
    fun setCharacteristicIndication(characteristic: BluetoothGattCharacteristic, enabled: Boolean) {
        try {
            if (mBluetoothAdapter == null || mBluetoothGatt == null) { //Check that we have a GATT connection
               // Log.i(TAG, "BluetoothAdapter not initialized")
                return
            }

            mBluetoothGatt!!.setCharacteristicNotification(characteristic, enabled)//Enable notification and indication for the characteristic

            for (des in characteristic.descriptors) {
                if (null != des) {
                    des.value = BluetoothGattDescriptor.ENABLE_INDICATION_VALUE//Set the value of the descriptor to enable indication
                    mBluetoothGatt!!.writeDescriptor(des)
                 //   Log.i(TAG, "***********************SET CHARACTERISTIC INDICATION SUCCESS**")//Write the descriptor
                }
            }
        } catch (e: Exception) {
         //   Log.i(TAG, e.message.toString())
        }

    }

    // Write to a given characteristic. The completion of the write is reported asynchronously through the
    // BluetoothGattCallback onCharacteristic Wire callback method.
    fun writeCharacteristic(characteristic: BluetoothGattCharacteristic) {
        try {

            if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have access to a Bluetooth radio

                return
            }
            val test = characteristic.properties                                      //Get the properties of the characteristic

            if (test and BluetoothGattCharacteristic.PROPERTY_WRITE == 0 && test and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0) { //Check that the property is writable

                return
            }
            if (mBluetoothGatt!!.writeCharacteristic(characteristic)) {                       //Request the BluetoothGatt to do the Write
                Log.i(TAG, "****************WRITE CHARACTERISTIC SUCCESSFUL**$characteristic")//The request was accepted, this does not mean the write completed
                /*  if(characteristic.getUuid().toString().equalsIgnoreCase(getString(R.string.char_uuid_missed_connection))){

                }*/
            } else {
                Log.i(TAG, "writeCharacteristic failed")                                   //Write request was not accepted by the BluetoothGatt
            }

        } catch (e: Exception) {
            Log.i(TAG, e.message.toString())
        }

    }

    // Retrieve and return a list of supported GATT services on the connected device
    fun getSupportedGattServices(): List<BluetoothGattService>? {

        return if (mBluetoothGatt == null) {                                                   //Check that we have a valid GATT connection

            null
        } else {
            Log.d("Hello","from getSupportedGattServices")
                mBluetoothGatt!!.services
        }

    }


    // Disconnects an existing connection or cancel a pending connection
    // BluetoothGattCallback.onConnectionStateChange() will get the result
    fun disconnect() {

        if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have a GATT connection to disconnect

            return
        }

        mBluetoothGatt?.disconnect()                                                    //Disconnect GATT connection
    }
    // Request a read of a given BluetoothGattCharacteristic. The Read result is reported asynchronously through the
    // BluetoothGattCallback onCharacteristicRead callback method.
    // For information only. This application uses Indication to receive updated characteristic data, not Read
    fun readCharacteristic(characteristic: BluetoothGattCharacteristic) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have access to a Bluetooth radio
            return
        }
        val status = mBluetoothGatt!!.readCharacteristic(characteristic)                              //Request the BluetoothGatt to Read the characteristic
       // Log.i(TAG, "READ STATUS $status")
    }

    /**
     * The remaining Data need to Update to the First Position Onwards
     *
     * @param byteValue
     * @param currentPos
     */
    private fun processData(byteValue: ByteArray, currentPos: Int) {
        var i = currentPos
        var j = 0
        while (i < byteValue.size) {
            mCompleResponseByte[j] = byteValue[i]
            i++
            j++
        }
    }

    private fun processIntent(intent: Intent?, isNeedToSend: Boolean) {
        if (isNeedToSend) {
            val value = String(mCompleResponseByte).trim { it <= ' ' } //new String(mCompleResponseByte, "UTF-8");
         //   Log.i(TAG, "MESSAGE Resp Complete message ===> $value")
            intent!!.putExtra(BLEConstants.EXTRA_DATA, value)
            sendBroadcast(intent)
        }
        for (i in mCompleResponseByte.indices) {
            mCompleResponseByte[i] = 0
        }
    }

    // Initialize by getting the BluetoothManager and BluetoothAdapter
    fun initialize(): Boolean {
        if (mBluetoothManager == null) {                                                //See if we do not already have the BluetoothManager
            mBluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager //Get the BluetoothManager

            if (mBluetoothManager == null) {                                            //See if we failed
             //   Log.i(TAG, "Unable to initialize BluetoothManager.")
                return false                                                           //Report the error
            }
        }
        mBluetoothAdapter = mBluetoothManager!!.adapter                             //Ask the BluetoothManager to get the BluetoothAdapter

        if (mBluetoothAdapter == null) {                                                //See if we failed
           // Log.i(TAG, "Unable to obtain a BluetoothAdapter.")

            return false                                                               //Report the error
        }

        return true                                                                    //Success, we have a BluetoothAdapter to control the radio
    }

    // Enable notification on a characteristic
    // For information only. This application uses Indication, not Notification
    fun setCharacteristicNotification(characteristic: BluetoothGattCharacteristic, enabled: Boolean) {
        try {

            if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have a GATT connection
               // Log.i(TAG, "BluetoothAdapter not initialized")

                return
            }
            mBluetoothGatt!!.setCharacteristicNotification(characteristic, enabled)          //Enable notification and indication for the characteristic

            for (des in characteristic.descriptors) {

                if (null != des) {
                    des.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE         //Set the value of the descriptor to enable notification
                    mBluetoothGatt!!.writeDescriptor(des)
                }

            }
        } catch (e: Exception) {
           // Log.i(TAG, e.message.toString())
        }
    }
    // Method to write an array to a specific characteristic

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val characteristicUuid: UUID? = intent?.getSerializableExtra("characteristicUuid") as? UUID
        val deviceAddress: String? = intent?.getSerializableExtra("deviceAddress") as? String
        val dataArray: ArrayList<Double>? = intent?.getSerializableExtra("dataArray") as? ArrayList<Double>

        Log.d("BLEService", "onStartCommand: Characteristic UUID: $characteristicUuid")
        Log.d("BLEService", "onStartCommand: Device Address: $deviceAddress")
        Log.d("BLEService", "onStartCommand: Data Array: $dataArray")

        deviceAddress?.let { BLEConnectionManager.connect(it) }
        mBluetoothGatt?.discoverServices()

        val gattServiceList = mBluetoothGatt?.services
        var characteristic: BluetoothGattCharacteristic? = null

        if (gattServiceList != null) {Log.d("BLE1", "Number of services in gattServiceList: ${gattServiceList?.size}")
      Log.d("Bello","${getSupportedGattServices()}")
            for (service in gattServiceList) {
                Log.d("BLE1", "onStartCommand: Service UUID: ${service.uuid}")

                for (char in service.characteristics) {
                    Log.d("BLEService", "onStartCommand: Characteristic UUID within Service ${service.uuid}: ${char.uuid}")
                    if (char.uuid == characteristicUuid) {
                        characteristic = char
                        Log.d("BLEService", "onStartCommand: Characteristic found within Service ${service.uuid}: ${char.uuid}")
                        break
                    }
                }

                if (characteristic != null) {
                    Log.d("BLEService", "onStartCommand: Found desired characteristic within Service ${service.uuid}")
                    break
                }
            }
        }

        if (characteristic != null) {
            Log.d("BLEService", "onStartCommand: Writing to characteristic")
            val doubleArray = dataArray?.toDoubleArray()
            val byteBuffer = ByteBuffer.allocate(8 * doubleArray!!.size)
            doubleArray?.forEach { byteBuffer.putDouble(it) }
            val byteArray = byteBuffer.array()
            characteristic.value = byteArray

            mBluetoothGatt?.writeCharacteristic(characteristic)
        } else {
            Log.d("BLEService", "onStartCommand: Characteristic not found")
        }

        return super.onStartCommand(intent, flags, startId)
    }


    fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic?) {
        if (characteristic != null) {
            val data = characteristic.value // Received byte array data from the Bluetooth device

            Log.d("BLEService", "onCharacteristicChanged: Received data length = ${data.size} bytes")
            Log.d("BLEService", "onCharacteristicChanged: Received data array = ${data.joinToString(", ") { it.toString() }}")

            processReceivedData(data)
        }
    }


    private fun processReceivedData(data: ByteArray) {
        Log.d("BLEService", "processReceivedData: Received data length = ${data.size} bytes")

        val receivedIntArray = IntArray(data.size / 4)
        val buffer = ByteBuffer.wrap(data)
        for (i in receivedIntArray.indices) {
            receivedIntArray[i] = buffer.int
        }

        Log.d("BLEService", "processReceivedData: Received data array = ${receivedIntArray.joinToString(", ")}")

        val intent = Intent(BLEConstants.ACTION_DATA_AVAILABLE)
        intent.putExtra(BLEConstants.EXTRA_DATA, receivedIntArray)
        sendBroadcast(intent)
    }

    // Inside your activity or fragment
    private val dataReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BLEConstants.ACTION_DATA_AVAILABLE) {
                val receivedData = intent.getIntArrayExtra(BLEConstants.EXTRA_DATA)

                val receivedDataString = receivedData?.joinToString(", ")
                Log.d("BLEService", "dataReceiver: Received data: $receivedDataString")

                // Update UI or perform other actions with receivedData
            }
        }
    }





}*/

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.eegreader.RecyclerView.PatientRecyclerAdaptor
import com.example.eegreader.SensorOutput
import com.example.eegreader.StatusDB.StatusViewModal
import com.example.eegreader.database.PatientDatabase
import com.example.eegreader.database.PatientRepository
import com.example.eegreader.database.PatientViewModal
import com.example.eegreader.database.PatientViewModalFactory
import com.example.eegreader.database.Patientlist
import com.example.eegreader.database.StatusList

import com.np.lekotlin.blemodule.BLEConnectionManager
import java.nio.ByteBuffer
import java.util.Locale
import java.util.UUID
import kotlin.experimental.and


class BLEService: Service() {
private lateinit var intent1:Intent
    private val TAG = "BLE"
    private lateinit var byteArray1:ByteArray
    private lateinit var byteArray:ByteArray
    private var servicesDiscovered = false
    private val mBinder = LocalBinder()//Binder for Activity that binds to this Service
    private var mBluetoothManager: BluetoothManager? =
        null//BluetoothManager used to get the BluetoothAdapter
    private var mBluetoothAdapter: BluetoothAdapter? =
        null//The BluetoothAdapter controls the BLE radio in the phone/tablet
    private var mBluetoothGatt: BluetoothGatt? =
        null//BluetoothGatt controls the Bluetooth communication link
    private var mBluetoothDeviceAddress: String? = null//Address of the connected BLE device
    private val mCompleResponseByte = ByteArray(100)


    private val mGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(
            gatt: BluetoothGatt,
            status: Int,
            newState: Int
        ) {//Change in connection state

            if (newState == BluetoothProfile.STATE_CONNECTED) {//See if we are connected
                Log.i(TAG, "**ACTION_SERVICE_CONNECTED**$status")
                broadcastUpdate(BLEConstants.ACTION_GATT_CONNECTED)//Go broadcast an intent to say we are connected
                gatt.discoverServices()
                mBluetoothGatt?.discoverServices()//Discover services on connected BLE device
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {//See if we are not connectedLog.i(TAG, "**ACTION_SERVICE_DISCONNECTED**" + status);
                broadcastUpdate(BLEConstants.ACTION_GATT_DISCONNECTED)//Go broadcast an intent to say we are disconnected
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            var characteristic: BluetoothGattCharacteristic? = null
            if (status == BluetoothGatt.GATT_SUCCESS) {
                gatt?.services?.forEach { gattService ->
                    gattService.characteristics.forEach { mCharacteristic ->

                                characteristic = mCharacteristic


                            }

                    val dataArray: ArrayList<Double>? =
                        intent1?.getSerializableExtra("dataArray") as? ArrayList<Double>

                    servicesDiscovered=true
                    Log.i(TAG, "onServicesDiscovered UUID: ${gattService.includedServices}")
                    val doubleArray = dataArray?.toDoubleArray()
                    val byteBuffer = ByteBuffer.allocate(8 * doubleArray!!.size)
                    doubleArray?.forEach { byteBuffer.putDouble(it) }
                    val byteArray = byteBuffer.array()
                    byteArray1="1,5,3".toByteArray()
                    Log.d("I","${byteArray}")
                    characteristic?.value = byteArray1
Log.d("hello","I am here")
                    val writeResult = gatt.writeCharacteristic(characteristic)
                    if (writeResult) {
                        Log.d(TAG, "Write operation initiated successfully")
                    } else {
                        Log.e(TAG, "Failed to initiate write operation")
                    }
                    Log.d("hello","I am there")
                }
            } else {
                Log.w(TAG, "onServicesDiscovered received: $status")
            }
        }


        //For information only. This application uses Indication to receive updated characteristic data, not Read
        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) { //A request to Read has completed
            //String value = characteristic.getStringValue(0);
            //int value = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT32, 0);
            val values = characteristic.value
            val clearValue = byteArrayOf(255.toByte())
            var value = 0

            if (null != values) {
                Log.i(TAG, "ACTION_DATA_READ VALUE: " + values.size)
                Log.i(TAG, "ACTION_DATA_READ VALUE: " + (values[0] and 0xFF.toByte()))

                value = (values[0] and 0xFF.toByte()).toInt()
            }

            BLEConnectionManager.writeEmergencyGatt(clearValue)

            if (status == BluetoothGatt.GATT_SUCCESS) {
                //See if the read was successful
                Log.i(TAG, "**ACTION_DATA_READ**$characteristic")
                broadcastUpdate(
                    BLEConstants.ACTION_DATA_AVAILABLE,
                    characteristic
                )                 //Go broadcast an intent with the characteristic data
            } else {
                Log.i(TAG, "ACTION_DATA_READ: Error$status")
            }

        }

        //For information only. This application sends small packets infrequently and does not need to know what the previous write completed
        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) { //A request to Write has completed
            if (status == BluetoothGatt.GATT_SUCCESS) {                                 //See if the write was successful
                Log.e(TAG, "**ACTION_DATA_WRITTEN**$characteristic")
                broadcastUpdate(
                    BLEConstants.ACTION_DATA_WRITTEN,
                    characteristic
                )                   //Go broadcast an intent to say we have have written data
            }
        }
        val responseArray = mutableListOf<Byte>()
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic?
        ) {

            if (characteristic != null && characteristic.properties == BluetoothGattCharacteristic.PROPERTY_NOTIFY) {
                Log.e(TAG, "**THIS IS A NOTIFY MESSAGE")
            }
            if (characteristic != null) {
                broadcastUpdate(BLEConstants.ACTION_DATA_AVAILABLE, characteristic)
            }

                val data = characteristic?.value
                // Append the received data to the responseArray
                responseArray.addAll(data?.asList()!!)

                // Display a Toast with the current responseArray content
                val responseMessage = "Response: ${responseArray.joinToString(" ")}"

            Toast.makeText(applicationContext, responseMessage, Toast.LENGTH_SHORT).show()

            //Go broadcast an intent with the characteristic data
        }


    }

    // An activity has bound to this service
    override fun onBind(intent: Intent): IBinder? {

        return mBinder                                                                 //Return LocalBinder when an Activity binds to this Service
    }

    // An activity has unbound from this service
    override fun onUnbind(intent: Intent): Boolean {

        if (mBluetoothGatt != null) {                                                   //Check for existing BluetoothGatt connection
            mBluetoothGatt!!.close()                                                     //Close BluetoothGatt coonection for proper cleanup
            mBluetoothGatt =
                null                                                      //No longer have a BluetoothGatt connection
        }

        return super.onUnbind(intent)
    }

    fun connect(address: String?): Boolean {
        try {

            if (mBluetoothAdapter == null || address == null) {                             //Check that we have a Bluetooth adappter and device address
                Log.i(
                    TAG,
                    "BluetoothAdapter not initialized or unspecified address."
                )     //Log a warning that something went wrong
                return false                                                               //Failed to connect
            }

            // Previously connected device.  Try to reconnect.
            if (mBluetoothDeviceAddress != null && address == mBluetoothDeviceAddress && mBluetoothGatt != null) { //See if there was previous connection to the device
                Log.i(TAG, "Trying to use an existing mBluetoothGatt for connection.")
                //See if we can connect with the existing BluetoothGatt to connect
                //Success
                //Were not able to connect
                return mBluetoothGatt!!.connect()
            }

            val device = mBluetoothAdapter!!.getRemoteDevice(address)
                ?: //Check whether a device was returned
                return false                                                               //Failed to find the device
            //No previous device so get the Bluetooth device by referencing its address

            mBluetoothGatt = device.connectGatt(
                this,
                false,
                mGattCallback
            )                //Directly connect to the device so autoConnect is false
            mBluetoothDeviceAddress =
                address                                              //Record the address in case we need to reconnect with the existing BluetoothGatt

            return true
        } catch (e: Exception) {
            Log.i(TAG, e.message.toString())
        }

        return false
    }

    // Broadcast an intent with a string representing an action
    private fun broadcastUpdate(action: String) {
        val intent =
            Intent(action)                                       //Create new intent to broadcast the action
        sendBroadcast(intent)                                                          //Broadcast the intent
    }

    // Broadcast an intent with a string representing an action an extra string with the data
    // Modify this code for data that is not in a string format
    private fun broadcastUpdate(action: String, characteristic: BluetoothGattCharacteristic) {
        //Create new intent to broadcast the action
        val intent = Intent(action)
        var dataValueHex = ""
        var dataValueNew = ""

        val value = characteristic.value
        if (value != null) {
            for (singleData in value) {
                dataValueHex =
                    dataValueHex + "\t" + "0x" + String.format(Locale.ENGLISH, "%02X", singleData)
                dataValueHex = dataValueHex.replace(",", ".")
                dataValueNew = " $singleData"
            }
            val intent = Intent(action)
            val dataValueList = ArrayList<Double>()

            val value = characteristic.value
            if (value != null) {
                for (singleData in value) {
                    dataValueList.add(singleData.toDouble())
                }



                val groceryRepository = PatientRepository(PatientDatabase(this))
                val factory = PatientViewModalFactory(groceryRepository)

                if (dataValueList.isNotEmpty()) {

                    val bioimpedance: Double = dataValueList[0]
                    val frequency: Double = dataValueList[2]
                    val phaseangle: Double = dataValueList[4]
                    val items = StatusList(1, bioimpedance, frequency, phaseangle)

                    StatusViewModal.insertitems(items)

                    val intent = Intent(this, SensorOutput::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) // Add this flag to start activity from a service
                    intent.putExtra("dataValueNew", dataValueList)
                    startActivity(intent)
                    Log.d("Checking","${dataValueList}")

                    LocalBroadcastManager.getInstance(this).sendBroadcast(intent)

                }
            }

        }


        intent.putExtra(BLEConstants.EXTRA_DATA, dataValueNew)
        intent.putExtra(BLEConstants.EXTRA_UUID, characteristic.uuid)

                sendBroadcast(intent)
            }

    // A Binder to return to an activity to let it bind to this service
    inner class LocalBinder : Binder() {
        internal fun getService(): BLEService {
            return this@BLEService//Return this instance of BluetoothLeService so clients can call its public methods
        }
    }

    // Enable indication on a characteristic
    fun setCharacteristicIndication(characteristic: BluetoothGattCharacteristic, enabled: Boolean) {
        try {
            if (mBluetoothAdapter == null || mBluetoothGatt == null) { //Check that we have a GATT connection
                Log.i(TAG, "BluetoothAdapter not initialized")
                return
            }

            mBluetoothGatt!!.setCharacteristicNotification(
                characteristic,
                enabled
            )//Enable notification and indication for the characteristic

            for (des in characteristic.descriptors) {
                if (null != des) {
                    des.value =
                        BluetoothGattDescriptor.ENABLE_INDICATION_VALUE//Set the value of the descriptor to enable indication
                    mBluetoothGatt!!.writeDescriptor(des)
                    Log.i(
                        TAG,
                        "***********************SET CHARACTERISTIC INDICATION SUCCESS**"
                    )//Write the descriptor
                }
            }
        } catch (e: Exception) {
            Log.i(TAG, e.message.toString())
        }

    }

    // Write to a given characteristic. The completion of the write is reported asynchronously through the
    // BluetoothGattCallback onCharacteristic Wire callback method.
    fun writeCharacteristic(characteristic: BluetoothGattCharacteristic) {
        try {Log.d("Hello","I am writing")

            if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have access to a Bluetooth radio

                return
            }
            val test =
                characteristic.properties                                      //Get the properties of the characteristic

            if (test and BluetoothGattCharacteristic.PROPERTY_WRITE == 0 && test and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0) { //Check that the property is writable

                return
            }
            if (mBluetoothGatt!!.writeCharacteristic(characteristic)) {                       //Request the BluetoothGatt to do the Write
                Log.i(
                    TAG,
                    "****************WRITE CHARACTERISTIC SUCCESSFUL**$characteristic"
                )//The request was accepted, this does not mean the write completed
                /*  if(characteristic.getUuid().toString().equalsIgnoreCase(getString(R.string.char_uuid_missed_connection))){

                }*/
            } else {
                Log.i(
                    TAG,
                    "writeCharacteristic failed"
                )                                   //Write request was not accepted by the BluetoothGatt
            }

        } catch (e: Exception) {
            Log.i(TAG, e.message.toString())
        }

    }

    // Retrieve and return a list of supported GATT services on the connected device
    fun getSupportedGattServices(): List<BluetoothGattService>? {

        return if (mBluetoothGatt == null) {                                                   //Check that we have a valid GATT connection

            null
        } else mBluetoothGatt!!.services

    }


    // Disconnects an existing connection or cancel a pending connection
    // BluetoothGattCallback.onConnectionStateChange() will get the result
    fun disconnect() {

        if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have a GATT connection to disconnect

            return
        }

        mBluetoothGatt?.disconnect()                                                    //Disconnect GATT connection
    }

    // Request a read of a given BluetoothGattCharacteristic. The Read result is reported asynchronously through the
    // BluetoothGattCallback onCharacteristicRead callback method.
    // For information only. This application uses Indication to receive updated characteristic data, not Read
    fun readCharacteristic(characteristic: BluetoothGattCharacteristic) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have access to a Bluetooth radio
            return
        }
        val status =
            mBluetoothGatt!!.readCharacteristic(characteristic)                              //Request the BluetoothGatt to Read the characteristic
        Log.i(TAG, "READ STATUS $status")
    }

    /**
     * The remaining Data need to Update to the First Position Onwards
     *
     * @param byteValue
     * @param currentPos
     */
    private fun processData(byteValue: ByteArray, currentPos: Int) {
        var i = currentPos
        var j = 0
        while (i < byteValue.size) {
            mCompleResponseByte[j] = byteValue[i]
            i++
            j++
        }
    }

    private fun processIntent(intent: Intent?, isNeedToSend: Boolean) {
        if (isNeedToSend) {
            val value =
                String(mCompleResponseByte).trim { it <= ' ' } //new String(mCompleResponseByte, "UTF-8");
            Log.i(TAG, "MESSAGE Resp Complete message ===> $value")
            intent!!.putExtra(BLEConstants.EXTRA_DATA, value)
            sendBroadcast(intent)
        }
        for (i in mCompleResponseByte.indices) {
            mCompleResponseByte[i] = 0
        }
    }

    // Initialize by getting the BluetoothManager and BluetoothAdapter
    fun initialize(): Boolean {
        if (mBluetoothManager == null) {                                                //See if we do not already have the BluetoothManager
            mBluetoothManager =
                getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager //Get the BluetoothManager

            if (mBluetoothManager == null) {                                            //See if we failed
                Log.i(TAG, "Unable to initialize BluetoothManager.")
                return false                                                           //Report the error
            }
        }
        mBluetoothAdapter =
            mBluetoothManager!!.adapter                             //Ask the BluetoothManager to get the BluetoothAdapter

        if (mBluetoothAdapter == null) {                                                //See if we failed
            Log.i(TAG, "Unable to obtain a BluetoothAdapter.")

            return false                                                               //Report the error
        }

        return true                                                                    //Success, we have a BluetoothAdapter to control the radio
    }

    // Enable notification on a characteristic
    // For information only. This application uses Indication, not Notification
    fun setCharacteristicNotification(
        characteristic: BluetoothGattCharacteristic,
        enabled: Boolean
    ) {
        try {

            if (mBluetoothAdapter == null || mBluetoothGatt == null) {                      //Check that we have a GATT connection
                Log.i(TAG, "BluetoothAdapter not initialized")

                return
            }
            mBluetoothGatt!!.setCharacteristicNotification(
                characteristic,
                enabled
            )          //Enable notification and indication for the characteristic

            for (des in characteristic.descriptors) {

                if (null != des) {
                    des.value =
                        BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE         //Set the value of the descriptor to enable notification
                    mBluetoothGatt!!.writeDescriptor(des)
                }

            }
        } catch (e: Exception) {
            Log.i(TAG, e.message.toString())
        }
    }

 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val characteristicUuid: UUID? = intent?.getSerializableExtra("characteristicUuid") as? UUID
        val deviceAddress: String? = intent?.getSerializableExtra("deviceAddress") as? String
     if (intent != null) {
         intent1=intent
     }
        val dataArray: ArrayList<Double>? =
            intent?.getSerializableExtra("dataArray") as? ArrayList<Double>

        Log.d("BLEService", "onStartCommand: Characteristic UUID: $characteristicUuid")
        Log.d("BLEService", "onStartCommand: Device Address: $deviceAddress")
        Log.d("BLEService", "onStartCommand: Data Array: $dataArray")

        deviceAddress?.let { BLEConnectionManager.connect(it) }
        mBluetoothGatt?.discoverServices()
     if (!servicesDiscovered) {
         // Services haven't been discovered yet, do not proceed
         return START_STICKY
     }

        val gattServiceList = mBluetoothGatt?.services
        var characteristic: BluetoothGattCharacteristic? = null

        if (gattServiceList != null) {
            Log.d("BLE1", "Number of services in gattServiceList: ${gattServiceList?.size}")
            Log.d("Bello", "${getSupportedGattServices()}")
            for (service in gattServiceList) {
                Log.d("BLE1", "onStartCommand: Service UUID: ${service.uuid}")

                for (char in service.characteristics) {
                    Log.d(
                        "BLEService",
                        "onStartCommand: Characteristic UUID within Service ${service.uuid}: ${char.uuid}"
                    )
                    if (char.uuid == characteristicUuid) {
                        characteristic = char
                        Log.d(
                            "BLEService",
                            "onStartCommand: Characteristic found within Service ${service.uuid}: ${char.uuid}"
                        )
                        break
                    }
                }

                if (characteristic != null) {
                    Log.d(
                        "BLEService",
                        "onStartCommand: Found desired characteristic within Service ${service.uuid}"
                    )
                    break
                }
            }
        }

        if (characteristic != null) {
            Log.d("BLEService", "onStartCommand: Writing to characteristic")
            val doubleArray = dataArray?.toDoubleArray()
            val byteBuffer = ByteBuffer.allocate(8 * doubleArray!!.size)
            doubleArray?.forEach { byteBuffer.putDouble(it) }
            val byteArray = byteBuffer.array()
            characteristic.value = byteArray

            mBluetoothGatt?.writeCharacteristic(characteristic)
        } else {
            Log.d("BLEService", "onStartCommand: Characteristic not found")
        }

        return super.onStartCommand(intent, flags, startId)
    }


    fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic?) {
        if (characteristic != null) {
            val data = characteristic.value // Received byte array data from the Bluetooth device

            Log.d(
                "BLEService",
                "onCharacteristicChanged: Received data length = ${data.size} bytes"
            )
            Log.d(
                "BLEService",
                "onCharacteristicChanged: Received data array = ${data.joinToString(", ") { it.toString() }}"
            )

            processReceivedData(data)
        }
    }


    private fun processReceivedData(data: ByteArray) {
        Log.d("BLEService", "processReceivedData: Received data length = ${data.size} bytes")

        val receivedIntArray = IntArray(data.size / 4)
        val buffer = ByteBuffer.wrap(data)
        for (i in receivedIntArray.indices) {
            receivedIntArray[i] = buffer.int
        }

        Log.d(
            "BLEService",
            "processReceivedData: Received data array = ${receivedIntArray.joinToString(", ")}"
        )

        val intent = Intent(BLEConstants.ACTION_DATA_AVAILABLE)
        intent.putExtra(BLEConstants.EXTRA_DATA, receivedIntArray)
        sendBroadcast(intent)
    }

    // Inside your activity or fragment
    private val dataReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BLEConstants.ACTION_DATA_AVAILABLE) {
                val receivedData = intent.getIntArrayExtra(BLEConstants.EXTRA_DATA)

                val receivedDataString = receivedData?.joinToString(", ")
                Log.d("BLEService", "dataReceiver: Received data: $receivedDataString")

                // Update UI or perform other actions with receivedData
            }
        }
    }

    fun readCustomCharacteristic() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized")
            return
        }
        /*check if the service is available on the device*/
        val mCustomService = mBluetoothGatt!!.getService(
            UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB")
        )
        if (mCustomService == null) {
            Log.w(TAG, "Custom BLE Service not found")
            return
        }
        /*get the read characteristic from the service*/
        val mReadCharacteristic = mCustomService.getCharacteristic(
            UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB")
        )
        if (mBluetoothGatt!!.readCharacteristic(mReadCharacteristic) == false) {
            Log.w(TAG, "Failed to read characteristic")
        }
    }

    fun writeCustomCharacteristic(value: Int) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized")
            return
        }
        /*check if the service is available on the device*/
        val mCustomService = mBluetoothGatt!!.getService(
            UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB")
        )
        if (mCustomService == null) {
            Log.w(TAG, "Custom BLE Service not found")
            return
        }
        /*get the read characteristic from the service*/
        val mWriteCharacteristic = mCustomService.getCharacteristic(
            UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB")
        )
        mWriteCharacteristic.setValue(value, BluetoothGattCharacteristic.FORMAT_UINT8, 0)
        if (mBluetoothGatt!!.writeCharacteristic(mWriteCharacteristic) == false) {
            Log.w(TAG, "Failed to write characteristic")
        }
    }
}